//
//  AuthMethod enum
//  PSA
//
//  Created by Borovik, Edgar2 on 1/30/20.
//
#import <Foundation/Foundation.h>

typedef NS_ENUM (NSInteger, AuthMethod){
    AuthMethodOK  = 1,
    AuthMethodPIN = 2,
    AuthMethodBIO = 3
};
