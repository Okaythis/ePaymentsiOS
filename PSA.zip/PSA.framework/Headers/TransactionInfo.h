//
//  TransactionInfo.h
//  PSA
//
//  Created by Borovik, Edgar2 on 2/12/20.
//

#import <Foundation/Foundation.h>
#import "OperationType.h"
#import "AuthMethod.h"
#import "ePaymentsUI/Payment.h"

@interface TransactionInfo : NSObject

@property OperationType operationType;
@property AuthMethod authMethod;
@property NSArray<Payment*> *payments;
@property NSDictionary<NSString*, NSString*> *args;

@end
