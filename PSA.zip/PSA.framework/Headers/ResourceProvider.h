//
//  ResourceProvider.h
//  PSA
//
//  Created by Borovik, Edgar2 on 1/30/20.
//

#import <Foundation/Foundation.h>
#import "OperationType.h"
#import "TransactionInfo.h"

@protocol ResourceProvider
@required

@property NSAttributedString *biometricAlertReasonText;
@property NSAttributedString *confirmActionHeaderText;
@property NSAttributedString *confirmButtonText;
@property NSAttributedString *confirmBiometricTouchButtonText;
@property NSAttributedString *confirmBiometricFaceButtonText;
@property NSAttributedString *cancelButtonText;
@property NSAttributedString *massPaymentDetailsButtonText;
@property NSAttributedString *massPaymentDetailsHeaderText;
@property NSAttributedString *feeLabelText;
@property NSAttributedString *recepientLabelText;
@property NSAttributedString *enrollmentTitleText;
@property NSAttributedString *enrollmentDescriptionText;

- (NSAttributedString*)stringForTransactionInfo:(TransactionInfo*)transactionInfo;

@end
