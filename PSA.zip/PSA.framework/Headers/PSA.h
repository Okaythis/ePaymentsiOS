//
//  PSA.h
//  PSA
//
//  Created by Borovik, Edgar2 on 3/5/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PSA.
FOUNDATION_EXPORT double PSAVersionNumber;

//! Project version string for PSA.
FOUNDATION_EXPORT const unsigned char PSAVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PSA/PublicHeader.h>
#import <PSA/PSAPublic.h>
#import <PSA/PSATenant.h>
#import <PSA/TransactionInfo.h>
