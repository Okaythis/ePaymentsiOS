// Copyright © Protectoria. All rights reserved.

#import <UIKit/UIKit.h>

@interface PSARoundButton : UIButton

@end
