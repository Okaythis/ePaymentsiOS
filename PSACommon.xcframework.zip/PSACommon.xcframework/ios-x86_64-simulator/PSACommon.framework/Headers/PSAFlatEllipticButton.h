// Copyright © Protectoria. All rights reserved.

#import <UIKit/UIKit.h>
#import "PSARoundButton.h"

@interface PSAFlatEllipticButton : PSARoundButton

@end
