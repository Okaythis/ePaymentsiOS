//
//  ePaymentsUI.h
//  ePaymentsUI
//
//  Created by Borovik, Edgar2 on 1/3/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ePaymentsUI.
FOUNDATION_EXPORT double ePaymentsUIVersionNumber;

//! Project version string for ePaymentsUI.
FOUNDATION_EXPORT const unsigned char ePaymentsUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ePaymentsUI/PublicHeader.h>

#import <ePaymentsUI/Payment.h>
#import <ePaymentsUI/PSASecurityProtocol.h>
#import <ePaymentsUI/AuthUiInitData.h>
