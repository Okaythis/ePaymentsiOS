//
//  Header.h
//  PSA
//
//  Created by Borovik, Edgar2 on 1/10/20.
//
#import <Foundation/Foundation.h>
@interface SimpleTimer : NSObject

- (instancetype)initWithTime:(int) seconds
                    callback:(void(^)(NSString *, int, float)) callback;

- (void)appendCallback:(void(^)(NSString *, int, float)) callback;

- (void)removeLastCallback;

- (NSInteger)callbacksCount;

- (void)start;

@end

