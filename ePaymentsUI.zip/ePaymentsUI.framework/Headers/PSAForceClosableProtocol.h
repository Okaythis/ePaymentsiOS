//
//  PSAForceClosableProtocol.h
//  ePaymentsUI
//
//  Created by Borovik, Edgar2 on 4/9/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

@protocol PSAForceClosable <NSObject>

- (void)forceClose;

@end
