//
//  PSABiometricAuthViewController.h
//  PSA
//
//  Created by Bulat, Maksim on 15/05/2019.
//

#import <UIKit/UIKit.h>
#import "AuthUiInitData.h"

NS_ASSUME_NONNULL_BEGIN
@protocol PSABiometricAuthViewControllerDelegate <NSObject>
- (void)biometricAuthViewControllerCancelled;
- (void)biometricAuthViewControllerConfirmedWithType:(NSString *)biometricType;
@end

@interface PSABiometricAuthViewController : UIViewController

+ (instancetype)controllerWithTheme:(nullable id)theme
                           delegate:(id<PSABiometricAuthViewControllerDelegate>)delegate
                           initData:(AuthUiInitData*)initData;

@end


NS_ASSUME_NONNULL_END
