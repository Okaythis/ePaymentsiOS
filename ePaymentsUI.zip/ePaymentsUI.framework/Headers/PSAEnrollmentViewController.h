//
//  PSAEnrollmentViewController.h
//  PSA
//
//  Created by Pivulski, Nikolai on 12/06/2018.
//

#import <UIKit/UIKit.h>
#import "PSACommon/PSASharedStatuses.h"
#import "PSAEnrollmentStartProtocol.h"
#import "PSAEnrollmentInitData.h"

NS_ASSUME_NONNULL_BEGIN

@interface PSAEnrollmentViewController : UIViewController

@property (strong, nonatomic) id <PSAEnrollmentStartProtocol> enrollmentController;
@property (copy, nonatomic, nullable) void (^completion)(PSASharedStatuses);
@property (nullable) PSAEnrollmentInitData *enrollmentInitData;

- (void)startInvisibly;

@end

NS_ASSUME_NONNULL_END
