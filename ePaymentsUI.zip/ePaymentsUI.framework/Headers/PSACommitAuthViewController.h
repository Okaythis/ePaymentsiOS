//
//  PSACommitAuthViewController.h
//  PSA
//
//  Created by Pivulski, Nikolai on 05.07.2018.
//

#import <UIKit/UIKit.h>
#import "AuthUiInitData.h"

NS_ASSUME_NONNULL_BEGIN

@protocol PSACommitAuthViewControllerDelegate;

@interface PSACommitAuthViewController : UIViewController

+ (instancetype)controllerWithTheme:(nullable id)theme
                           delegate:(id<PSACommitAuthViewControllerDelegate>)delegate
                           initData:(AuthUiInitData*)initData;

@end

@protocol PSACommitAuthViewControllerDelegate <NSObject>
- (void)commitAuthViewControllerCancelled:(PSACommitAuthViewController *)controller withTimeoutError:(BOOL)hasTimeoutError;
- (void)commitAuthViewControllerConfirmed:(PSACommitAuthViewController *)controller;
@end

NS_ASSUME_NONNULL_END
