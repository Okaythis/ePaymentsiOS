//
//  PSAEnrollmentInitData.h
//  ePaymentsUI
//
//  Created by Borovik, Edgar2 on 3/4/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

@interface PSAEnrollmentInitData : NSObject

@property NSAttributedString *bindingDeviceTitle;
@property NSAttributedString *bindingDeviceDescription;

- (instancetype)initWithTitle:(NSAttributedString *)title description:(NSAttributedString *)description;
@end
