//
//  Header.h
//  ePaymentsUI
//
//  Created by Borovik, Edgar2 on 1/15/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface TimerProgressView : UIView

- (instancetype)initWithCoder:(NSCoder *)aDecoder;

- (void)setProgress:(float) progress;

- (float)getProgress;
@end
