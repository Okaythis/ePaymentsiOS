//
//  PaymentDetailsViewController.h
//  ePaymentsUI
//
//  Created by Borovik, Edgar2 on 1/17/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TimerProgressView.h"
#import "SimpleTimer.h"
#import "AuthUiInitData.h"
NS_ASSUME_NONNULL_BEGIN

@interface PaymentDetailsViewController : UIViewController <UITableViewDataSource>
@property (weak, nonatomic) IBOutlet TimerProgressView *timerProgressView;
@property (weak, nonatomic) IBOutlet UILabel *timerLabel;
@property (weak, nonatomic) IBOutlet UITableView *paymentsTableView;
@property (weak, nonatomic) IBOutlet UILabel *massPaymentHeader;
@property (weak, nonatomic) IBOutlet UIButton *closeButton;

- (void)setupWithTimer:(SimpleTimer*)timer
              initData:(AuthUiInitData*)initData
              timerText:(NSString*)timerText
         timerProgress:(float)timerProgress;

@end
NS_ASSUME_NONNULL_END
